# Classify Iris Species
Predict the species of an iris flower (setosa, verginica, or versicolor) given some of its properties.

### Tags
[classification] [gradient_boosting] [multi-class-classification] [R] [supervised-learning] [xgboost]
