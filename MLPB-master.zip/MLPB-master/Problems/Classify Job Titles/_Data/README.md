# Job Titles

#### Description
A fictitious dataset of job titles and a categorical classification of those titles.
