# Dart Thrower Data

#### Description
This hypothetical data represents darts thrown by four people. By default, the location of the darts is designed to make stacking an effective techinque for getting high classification accuracy. The file data_generation.R can be modified to generate more or different dart samples.